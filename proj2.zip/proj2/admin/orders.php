<?php
include 'db.php';
include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/navbar.php';
?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="container-fluid">
        <h3 class="mt-4 text-gray-600">Featured orders</h3>
    </div>
    <br>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Orders</h6>
            <button class=" float-right" data-toggle="modal" data-target="#addOrder"><i class="fa fa-plus"></i> Add order</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>OrderNumber</th>
                        <th>Customer Name</th>
                        <th>Product Name</th>
                        <th>Amount</th>
                        <th>Payment</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $sql = "SELECT * FROM sales ";
                    $query = mysqli_query($con,$sql);
                    while($fetch = mysqli_fetch_array($query)){
                        ?>
                        <tr>
                            <td><?php echo $fetch['sales_id']?></td>
                            <td><?php
                                $id =$fetch['user_id'];
                                $query = "SELECT * FROM users WHERE user_id='$id'";
                                $run = mysqli_query($con,$query);
                                while($row=mysqli_fetch_assoc($run)){
                                    echo $row['fname'];
                                }
                                ?>
                            </td>
                            <td><?php
                                $name =$fetch['product_id'];
                                $query = "SELECT * FROM products WHERE product_id='$name'";
                                $run = mysqli_query($con,$query);
                                while($row=mysqli_fetch_assoc($run)){
                                    echo $row['product_name'];
                                }
                                ?>
                            </td>
                            <td><?php echo $fetch['amount']?></td>
                            <td><?php echo $fetch['payment']?></td>

                        </tr>
                        <?php
                    }
                    ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
<?php

include 'includes/scripts.php';
include 'includes/modal.php';